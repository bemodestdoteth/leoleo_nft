## Klaytn IDE develop environment
remixd -s <path-to-the-shared-folder> -u <remix-ide-instance-URL> 
remixd -s C:\Users\runde\Documents\Mint_Leo -u https://ide.klaytn.com/#optimize=false&runs=200&evmVersion=constantinople&version=soljson-v0.5.6+commit.e28d00a7.js

## Metadata before reveal
https://ipfs.io/ipfs/QmVZmHx4wMr3Tt9EXdWQdBAhSBeti83HEihEVYfwCR2ZuK/

## Art before reveal
https://ipfs.io/ipfs/QmZB28X9r5EB1s4pyh3dxeaUN5dbEdbRAyWdqivU42EKL1/

## Metadata after reveal
https://ipfs.io/ipfs/QmT2jysS5eGFfrHyAvbaERJngY21CbAGKAH2UZuijMGneH/

## Art after reveal
https://ipfs.io/ipfs/QmTpyFjsoExKfcV6hHuEmGcLNjTxWZUVNzZS61M7Q5uact/